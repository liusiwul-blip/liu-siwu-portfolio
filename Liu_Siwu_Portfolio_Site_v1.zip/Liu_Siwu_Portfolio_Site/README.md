# Liu Siwu (Mc) — Interior Design Portfolio (working draft)

This is a first working website version built from the two portfolio PDFs supplied so far:

- `Portfolio - Liu Siwu (Mc).pdf` — Year 3 portfolio
- `Portfolio - DD 1101 Creative Thinking-Siwu Liu Mc.pdf` — selected Year 2 work

## Run locally

1. Extract the ZIP archive, keeping `index.html` and the `assets` folder together.
2. Open `index.html` in a modern browser. No build tools or external libraries are required.
3. For local HTTP preview, run `python -m http.server 8000` from the extracted folder and open `http://localhost:8000`.

## Current features

- Responsive home, selected-work grid, filters, about, moving-image and contact sections.
- Nine project detail overlays populated with page imagery rendered from the supplied PDFs.
- Keyboard Escape to close project details and browser-history hash support.
- Clear placeholders for video and contact details that have not been supplied yet.

## Important notes

- This is an initial curated version, not the final IN3010 submission.
- New project materials can be added later without rebuilding the site from scratch.
- The moving-image slots are intentionally placeholders because video files were not included in the current uploads.
- Contact information is intentionally left unfilled rather than inventing an email or social account.
- Project narratives are concise editorial summaries inferred from the visible project titles and spreads; review and correct them if any detail needs adjustment.
- The first document provided was considered the Year 3 portfolio and the second a partial Year 2 portfolio, following the student's description.
